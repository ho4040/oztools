import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class alphamaker_js extends PApplet {

PImage bg;
PImage img;  
PImage resultImage;
int w = 500;
int h = 400;
public void setup() {  
  size(w, h);
  bg = loadImage("bg.png");
}

public void fileSelected(File selection) {
  if (selection == null) {
    println("Window was closed or the user hit cancel.");
  } else {
    img = loadImage(selection.getAbsolutePath());
    PImage dst = createImage(img.width, img.height, ARGB);
    runProc(img, dst);
  }
}

public void saveFileSelected(File selection) {
  if (selection == null) {
    println("Window was closed or the user hit cancel.");
  } else {
    if(resultImage!=null)
      resultImage.save(selection.getAbsolutePath() + ".png");
  }
}

public void runProc(PImage src, PImage dst){
  
  img.loadPixels();  
  dst.loadPixels();
  for (int i = 0; i < src.pixels.length; i++) {
    int c = src.pixels[i];
    dst.pixels[i] = color(0,0,0, 255-brightness(c));
  }
  dst.updatePixels();
  resultImage = dst;
}

public void draw(){
  //background(0, 255, 0);
  image(bg,0,0);
  
  if(resultImage!= null){
    float fullX = resultImage.width - w;
    float fullY = resultImage.height - h;
    float rX = PApplet.parseFloat(mouseX)/w;
    float rY = PApplet.parseFloat(mouseY)/h;
    image(resultImage, -fullX*rX, -fullY*rY);
  }
  textSize(32);
  String str = "click:load  right-click : save";
  fill(255, 255, 255);
  text(str, 10, 30); 
  fill(0, 102, 153);
  text(str, 10, 32);
}

public void mouseClicked() {
  if(mouseButton == LEFT)
  {
    selectInput("Select a file to process:", "fileSelected");
  }else{
    selectInput("Select a save path:", "saveFileSelected");
  }
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "alphamaker_js" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
